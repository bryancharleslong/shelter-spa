export default function Footer() {
    return `
    <small>&copy Bryan 2019</small>
    `
}