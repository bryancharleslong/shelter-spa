export default function Header() {
    return `
    <nav class= 'nav_header'>
    <ul>
        <li class="nav__home">Home</li>
        <li class="nav__pets">Pets</li>
        <li class="nav__cages">Cages</li>
    </ul>
    </nav>
    `
}