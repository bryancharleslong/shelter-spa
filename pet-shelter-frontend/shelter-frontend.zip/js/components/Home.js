export default function Home() {
    return `
        <div>
            <h1>Welcome to Pet Shelter</h1>
            <p>Thanks for volunteering!</p>
        </div>
    `
}